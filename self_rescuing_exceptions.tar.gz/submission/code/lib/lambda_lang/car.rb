module LambdaLang
  class Car
    def initialize(cons)
      @cons = cons
    end

    attr_reader :cons
  end
end
